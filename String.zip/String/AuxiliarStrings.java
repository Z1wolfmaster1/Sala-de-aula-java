package String;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class AuxiliarStrings {
    Scanner input = new Scanner(System.in);
    private String s, alfabeto="abcdefghijklmnopkrstuvwxyz";
    private int contVogal=0, contPalavras=0, cont=0;

    public void setS(String s) {
        if(cont==0)
        this.s = s;
        
        cont++;
    }
    
    public String getS() {
        return s;
    }
    
    void contarVogal(){
        for(int i=0; i<s.length(); i++){
            for(int j=0; j<alfabeto.length(); j++){
                if(s.charAt(i)==alfabeto.charAt(j)){
                    contVogal++;
                }
            }
        }
    }
}