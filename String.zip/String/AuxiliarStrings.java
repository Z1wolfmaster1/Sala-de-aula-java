package String;

import java.util.Scanner;

public class AuxiliarStrings {
    Scanner input = new Scanner(System.in);
    private String s;
    private final String alfabeto = "abcdefghijklmnopkrstuvwxyz0123456789";
    private final String vogais= "aeiou";
    private int contVogal=0, contPalavras=0;

    public void setS(String s) {
        this.s = s;
    }
    
    public String getS() {
        return s;
    }
    
    int contarVogal(){
        for(int i=0; i<s.length(); i++){
            for(int j=0; j<vogais.length(); j++){
                if(s.charAt(i)==vogais.charAt(j)){
                    contVogal++;
                }
                
                else if(s.charAt(i)==' '&&s.charAt(i+1)!=' '){
                    contPalavras++;
                }
            }
        }
        
        return contVogal;
    }
    
    int contarPalavras(){
        return contPalavras;
    }
    
    String criptografar(){
        String sEncrip;
        sEncrip = s.replace('a', '*');
        sEncrip = sEncrip.replace('e', '*');
        sEncrip = sEncrip.replace('i', '*');
        sEncrip = sEncrip.replace('o', '*');
        sEncrip = sEncrip.replace('u', '*');
        return sEncrip;
    }
    
    boolean veriPalindromo(){
        String palindromo=s;
        boolean veri=false;
        for(int i=s.length()-1, j=0; i>-1; i--, j++){
            palindromo+=s.charAt(i);
        }
        
        if(s.equals(palindromo)){
            veri=true;
        }
        
        return veri;
    }
    
    boolean veriEmail(){
        int arrobaCont=0;
        boolean veri=true;
        
        for(int i=0; i<s.length(); i++){
            if(i==0&&s.charAt(i)=='.'||i==0&&s.charAt(i)=='_'||i==0&&s.charAt(i)=='@'){
                veri=false;
                break;
            }
            
            for(int j=0; j<alfabeto.length(); j++){
                if(s.charAt(i)=='@'&&s.charAt(i+1)!='.'){
                    arrobaCont++;
                }
                
                if(s.charAt(i)=='.'&&s.charAt(i+1)!='.'||s.charAt(i)=='_'&&s.charAt(i+1)!='_'){
                    veri=false;
                    break;
                }
                
                if(s.charAt(i)==alfabeto.charAt(j)){
                    break;
                }
                
                else if(j==alfabeto.length()-1){
                    veri=false;
                }
            }
        }
        
        if(arrobaCont==0||arrobaCont>1){
            veri=false;
        }

        return veri;
    }
}