public class revista extends produto{
    String periodicidade;
    public revista(String nome, float preco, fornecedor forn, String periodicidade){
        super(nome,preco,forn);
        this.periodicidade=periodicidade;
    }
}
