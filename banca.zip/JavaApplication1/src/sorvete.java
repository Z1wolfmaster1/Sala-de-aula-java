public class sorvete extends produto{
    String sabor;
    public sorvete(String nome, float preco, fornecedor forn, String sabor) {
        super(nome, preco, forn);
        this.sabor=sabor;
    }
    
}
