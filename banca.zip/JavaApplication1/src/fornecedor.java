public class fornecedor {
    String nome;
    String telefone;
}