public abstract class produto {
    String nome;
    float preco;
    fornecedor forn;
    
    public produto(String nome, float preco, fornecedor forn){
    this.nome=nome;
    this.preco=preco;
    this.forn=forn;
    }
}