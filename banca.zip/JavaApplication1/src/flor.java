public class flor extends produto{
    String especie;
    public flor(String nome, float preco, fornecedor forn, String especie){
        super(nome,preco,forn);
        this.especie=especie;
    }
}