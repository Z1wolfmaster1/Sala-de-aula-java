package Cinema;

import java.util.Scanner;

public class Principal {
    public static void main(String args[]){
        Scanner input=new Scanner(System.in);
        double x;
        EntradaCinema[] ent=new EntradaCinema[5];
        ent[0]=new EntradaCinema("Deadpool 2","23/05","Inicio da tarde","14:30","1",14);
        ent[1]=new EntradaCinema("Vingadores: Guerra Infinita","23/05","Inicio da tarde","","",14);
        ent[2]=new EntradaCinema("","23/05","Inicio da tarde","","",14);
        ent[3]=new EntradaCinema("","23/05","Inicio da tarde","","",14);
        ent[4]=new EntradaCinema("","23/05","Inicio da tarde","","",14);
        
        for(;;){
            System.out.printf("1. Comprar\n2. Trocar sessão\n3. Lucro\n4. Valor de cada entrada\n5. Sair\n\n=> ");
            x=input.nextDouble();
            
            if(x==1){
                
            }
            else if(x==2){}
            else if(x==3){}
            else if(x==4){}
            else if(x==5){}
        }
    }
}