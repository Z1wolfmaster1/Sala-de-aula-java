package Aula2;


public class Funcionario extends Pessoa {
    private String dataAdmissao;
    private double salario;
    
    public Funcionario(String nome, String cpf, String endereço, String dataAdmissao, double salario){
        super (nome, cpf, endereço);
        this.dataAdmissao=dataAdmissao;
        this.salario=salario;
    }
    
    void cadastrar(){
        
    }
    
    void exibirDados(){
        
    }
    
    void reajustarSalario(double reajuste){
        
    }
}
