package String;

import java.util.Scanner;

public class AuxiliarStrings {
    Scanner input = new Scanner(System.in);
    private String s;
    private final String alfabeto = "abcdefghijklmnopkrstuvwxyz0123456789";
    private final String vogais= "aeiou";
    private int contVogal, contPalavras;

    public void setS(String s) {
        this.s = s;
    }
    
    public String getS() {
        return s;
    }
    
    int contarVogal(){
        contVogal=0;
        for(int i=0; i<s.length(); i++){
            for(int j=0; j<vogais.length(); j++){
                if(s.charAt(i)==vogais.charAt(j)){
                    contVogal++;
                }
            }
        }
        
        return contVogal;
    }
    
    int contarPalavras(){
        contPalavras=0;
        
        for(int i=0; i<s.length(); i++){
            if(i==1){
                if(s.charAt(0)>='a' && s.charAt(0)<='z'||s.charAt(0)>='A' && s.charAt(0)<='Z')
                  contPalavras++;  
            }
            
            if(s.charAt(i)==' '){
                contPalavras++;
            }
        }
        
        return contPalavras;
    }
    
    String criptografar(){
        String sEncrip;
        sEncrip = s.replace('a', '*');
        sEncrip = sEncrip.replace('e', '*');
        sEncrip = sEncrip.replace('i', '*');
        sEncrip = sEncrip.replace('o', '*');
        sEncrip = sEncrip.replace('u', '*');
        return sEncrip;
    }
    
    boolean veriPalindromo(){
        boolean veri=true;
        for(int i=s.length()-1, j=0; i>-1; i--, j++){
            if(s.charAt(j)!=s.charAt(i)){
                veri=false;
            }
        }
        
        return veri;
    }
    
    boolean veriEmail(){
        int arrobaCont=0;
        boolean veri=true;
        
        for(int i=0; i<s.length(); i++){
            if(s.charAt(0)=='.'||s.charAt(0)=='_'||s.charAt(0)=='@'){
                veri=false;
                break;
            }
            
            if(s.charAt(i)=='@'&&s.charAt(i+1)!='.'){
                arrobaCont++;
            }

            if(s.charAt(i)=='.'&&s.charAt(i+1)=='.'||s.charAt(i)=='_'&&s.charAt(i+1)=='_'){
                veri=false;
                break;
            }
            
            if(s.charAt(0)<'a'&&s.charAt(0)>'z'||s.charAt(0)<'A'&&s.charAt(0)>'Z'){
                veri=false;
                break;
            }
            
            if(s.charAt(i)!='@'&&s.charAt(i)!='.'&&s.charAt(i)!='_'&&(s.charAt(i)<'a'&&s.charAt(i)>'z'||s.charAt(i)<'A'&&s.charAt(i)>'Z'||s.charAt(i)<'0'&&s.charAt(i)>'9')){
                veri=false;
                break;
            }
        }
        
        if(arrobaCont!=1){
            veri=false;
        }

        return veri;
    }
}