package Calendar;

import java.util.Calendar;

public class Principal {
    public static void main(String args[]){
        Calendar cal= Calendar.getInstance();
        
        int ano;
        int mes;
        int dia;
        int hora;
        int minuto;
        int segundo;
        
        for(;;){
            ano = cal.get(Calendar.YEAR);
            mes = cal.get(Calendar.MONTH);
            dia = cal.get(Calendar.DAY_OF_MONTH);
            hora = cal.get(Calendar.HOUR_OF_DAY);
            minuto = cal.get(Calendar.MINUTE);
            segundo = cal.get(Calendar.SECOND);

            System.out.println(hora+":"+minuto+":"+segundo+"\n"+dia+"/"+(mes+1)+"/"+ano);
            System.out.println("\n\n");
        }
        
    }
}
