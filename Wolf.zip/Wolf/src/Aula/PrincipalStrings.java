package Aula;

import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.Random;


public class PrincipalStrings {

    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        Random random=new Random();
        String frase, alfabeto="abcdefghijklmnopkrstuvwxyz";

        frase = JOptionPane.showInputDialog("Quer ver uma coisa legal?");
        if (frase.equalsIgnoreCase("sim")) {
            frase = JOptionPane.showInputDialog("Digite uma frase:");
            for(;;){
                frase = frase.replace(frase.charAt(random.nextInt(frase.length())),alfabeto.charAt(random.nextInt(alfabeto.length())));
                JOptionPane.showMessageDialog(null, frase + "\nSua frase foi zuada");
            }
        }
    }
}