package Exercicio_2;

public class CD extends Produto{
    private int numeroFaixas;

    @Override
    public void cadastrar(){
        super.cadastrar();
        System.out.print("Número de faixas: ");
        numeroFaixas=input.nextInt();
    }
}