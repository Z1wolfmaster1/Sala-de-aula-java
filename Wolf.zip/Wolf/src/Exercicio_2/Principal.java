package Exercicio_2;

import java.util.Calendar;

public class Principal {
    public static void main(String args[]){
        Calendar data = Calendar.getInstance();
        System.out.println(data.get(Calendar.DAY_OF_WEEK));
    }
}
