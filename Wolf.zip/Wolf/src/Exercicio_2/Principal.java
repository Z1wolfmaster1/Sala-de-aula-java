package Exercicio_2;

import java.util.Scanner;

public class Principal {
    public static void main(String args[]){
        Scanner input=new Scanner(System.in);
        Gerencia g=new Gerencia();
        int x;
        
        for(;;){
            System.out.print("");
            x=input.nextInt();
            
            if(x==1){
                System.out.print("1. Livro\n2. DVD\n3. CD\n\n=>");
                x=input.nextInt();
                g.cadastro(x);
            }
            
            else if(x==2){
                System.out.print("Titulo: ");
                x=input.nextInt();
                System.out.print("Titulo: ");
                x=input.nextInt();
                g.cadastro(x);
            }
            
            else if(x==3){
                g.exbirProduto();
            }
        }
        
    }
}
