package Exercicio_2;

import java.util.Calendar;
import java.util.Scanner;

public class Produto {
    Scanner input=new Scanner(System.in);
    private Calendar data = Calendar.getInstance();
    private String titulo;
    private double preço;

    public Produto(String titulo, double preço) {
        this.titulo = titulo;
        this.preço = preço;
    }
    
    public Produto(){}
    
    public void exibir(){
        System.out.println("Título: "+titulo+"\nPreço: "+preço);
    }
    
    double calcularDesconto(Produto p){
        int dia = data.get(Calendar.DAY_OF_WEEK);
        double preçoDesc=0;
        
        if(p instanceof Livro){
            if(data.get(Calendar.DAY_OF_WEEK)==Calendar.MONDAY||data.get(Calendar.DAY_OF_WEEK)==Calendar.WEDNESDAY){
                preçoDesc=preço-preço*0.3;
            }
        }
        
        else if(p instanceof DVD){
            if(data.get(Calendar.DAY_OF_WEEK)==Calendar.FRIDAY){
                preçoDesc=preço-preço*0.15;
            }
        }
        
        else if(p instanceof CD){
            if(data.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY||data.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY){
                preçoDesc=preço-preço*0.25;
            }
        }
        
        return preçoDesc;
    }
    
    public void cadastrar(){
        System.out.print("Titulo: ");
        titulo=input.nextLine();
        System.out.print("Preço: ");
        preço=input.nextDouble();
    }
}