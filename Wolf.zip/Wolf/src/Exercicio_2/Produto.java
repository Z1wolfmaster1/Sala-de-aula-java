package Exercicio_2;

import java.util.Calendar;

public class Produto {
    Calendar data = Calendar.getInstance();
    private String veri;
    private String titulo;
    private double preço;
    
    void exibir(){
        System.out.println("Título: "+titulo+"\nPreço: "+preço);
    }
    
    double calcularDesconto(String veri){
        int dia = data.get(Calendar.DAY_OF_WEEK);
        double preçoDesc=0;
        
        if(this.veri.equals(veri)){
            if(data.get(Calendar.DAY_OF_WEEK)==2||data.get(Calendar.DAY_OF_WEEK)==4){
                preçoDesc=preço-preço*0.3;
            }
            
        }
        
        else if(this.veri.equals(veri)){
            if(data.get(Calendar.DAY_OF_WEEK)==2||data.get(Calendar.DAY_OF_WEEK)==4){
                preçoDesc=preço-preço*0.3;
            }
            
        }
        
        if(this.veri.equals(veri)){
            if(data.get(Calendar.DAY_OF_WEEK)==2||data.get(Calendar.DAY_OF_WEEK)==4){
                preçoDesc=preço-preço*0.3;
            }
            
        }
        return preçoDesc;
    }
}
