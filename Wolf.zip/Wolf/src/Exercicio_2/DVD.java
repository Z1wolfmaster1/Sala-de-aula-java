package Exercicio_2;

public class DVD extends Produto{
    private int duraçao;
    
    @Override
    public void cadastrar(){
        super.cadastrar();
        System.out.print("Duração: ");
        duraçao=input.nextInt();
    }
}