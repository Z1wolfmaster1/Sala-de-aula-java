package Exercicio_2;

public class Livro extends Produto{
    
}
