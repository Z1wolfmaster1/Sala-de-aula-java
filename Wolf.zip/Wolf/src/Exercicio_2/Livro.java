package Exercicio_2;

public class Livro extends Produto{
    private String autor;
    
    @Override
    public void cadastrar(){
        super.cadastrar();
        System.out.print("Autor: ");
        autor=input.next();
    }
    
    @Override
    public void exibir(){
        super.exibir();
        System.out.println("Autor: "+autor);
    }
}