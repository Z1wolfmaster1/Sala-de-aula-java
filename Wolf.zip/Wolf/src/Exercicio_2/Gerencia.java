package Exercicio_2;

import java.util.Scanner;

public class Gerencia {
    Scanner input=new Scanner(System.in); 
    private Produto[] produtos=new Produto[1000];
    int cont=0;
    
    public void cadastro(int x){
        if(x==1){
            produtos[cont]=new Livro();
            produtos[cont].cadastrar();
            cont++;
        }
        
        else if(x==2){
            produtos[cont]=new DVD();
            produtos[cont].cadastrar();
            cont++;
        }
        
        else if(x==3){
            produtos[cont]=new CD();
            produtos[cont].cadastrar();
            cont++;
        }
    }
    
    public void exbirProduto(){
        for(int i=0; i<produtos.length; i++){
            if(produtos[i] instanceof Livro){
                produtos[i].exibir();
            }
        }
    }
}
