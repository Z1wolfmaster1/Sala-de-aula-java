package Padaria;

import java.util.Scanner;

public class Comanda {
    Scanner input=new Scanner(System.in);
    Produto[] produtos=new Produto[10];
    int numero, q;
    String s;
    double x;
    
    void exibirDados(){
        System.out.printf("Produtos:\n\n");
        for(int i=0; i<produtos.length; i++){
            produtos[i].exibirProduto();
            System.out.printf("\n");
        }
    }
    
    void atualizarquantidade(){
        System.out.printf("Escolha um produto: ");
        for(int i=0; i<produtos.length; i++){
            System.out.printf("\n"+(i+1)+". "+produtos[i].nome);
        }
        
        System.out.printf("\n\n==> ");
        q=input.nextInt();
        q--;
        
        System.out.printf("Digite a nova quantidade para "+produtos[q]+": ");
        x=input.nextDouble();
        produtos[q].quantidade=(int)x;
    }
    
    void realizarCompra(){
        for(int i=0; i<10; i++){
            System.out.print("1. Adicionar produto\n2. Próximo\n\n==> ");
            x=input.nextDouble();
            
            if(x==1){
               System.out.print("Nome do produto: ");
                s=input.next();
                System.out.printf("\nPreço: ");
                x=input.nextDouble();
                System.out.printf("\nQuantidade: ");
                q=input.nextInt();

                produtos[i]=new Produto(s,x,q); 
            }
            
            else if(x==2){
                break;
            }
        }
    }
    
    public Comanda(int numero){
        this.numero=numero;
    }
}