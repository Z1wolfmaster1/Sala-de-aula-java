package Padaria;

import java.util.Scanner;

public class Produto {
    Scanner input=new Scanner(System.in);
    String nome;
    double preco;
    int quantidade;
    
    void cadastrarProduto(){
        System.out.print("Nome do produto: ");
        input.nextLine();
        System.out.printf("\nPreço: ");
        input.nextDouble();
    }
    
    void exibirProduto(){
        System.out.printf("Nome do produto: %s. Preço: %.2f", nome, preco);
    }
    
    public Produto(String nome, double preco, int quantidade){
        this.nome=nome;
        this.preco=preco;
        this.quantidade=quantidade;
    }
}