package Padaria;

import java.util.Scanner;

public class Principal {
    public static void main(String args[]){
        Scanner input=new Scanner(System.in);
        Comanda[] compras=new Comanda[2];
        for(int i=0; i<2; i++){
            compras[i]=new Comanda((i+1));
        }
        
        double caixa=0, x;
        
        for(int i=0;; i++){
            System.out.printf("Caixa: R$%.2f\n\n1. Realizar venda\n2. Exibir compras\n3. Sair\n\n==>", caixa);
            x=input.nextDouble();
            
            if(x==1){
                compras[i].realizarCompra();
                for(int j=0; j<compras[i].produtos.length; j++){
                    caixa+=compras[i].produtos[j].preco*compras[i].produtos[j].quantidade;
                }
            }
            else if(x==2){
                for(int j=0; j<compras.length; j++){
                    System.out.printf("%dº Comanda", j+1);
                    compras[j].exibirDados();
                }
            }
            else if(x==3){
                break;
            }
        }
    }
}