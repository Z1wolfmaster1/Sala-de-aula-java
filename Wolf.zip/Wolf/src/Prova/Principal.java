package Prova;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String args[]){
        Scanner input=new Scanner(System.in);
        StringAuxiliar string=new StringAuxiliar();
        int x;
        
        string.setS(JOptionPane.showInputDialog("Digite uma frase:"));
        
        for(;;){
            x=Integer.parseInt(JOptionPane.showInputDialog("1. Verificar CPF\n2. Verificar quase palindroma\n3. Quase palindroma criptografada\n4. Sair"));
            
            if(x==1){
                if(string.verificarcpf()){
                    JOptionPane.showMessageDialog(null, "CPF válido");
                }
                
                else{
                    JOptionPane.showMessageDialog(null, "CPF inválido");
                }
            }
            else if(x==2){
                if(string.quasePalindroma()){
                    JOptionPane.showMessageDialog(null, "Quase palindroma");
                }
                
                else{
                    JOptionPane.showMessageDialog(null, "Não quase palindroma");
                }
            }
            
            else if(x==3){
                JOptionPane.showMessageDialog(null, string.quasePalindromaCriptografado());
            }
            else if(x==4){
                break;
            }
            else{}
        }
    }
}