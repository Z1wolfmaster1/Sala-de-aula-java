package Prova;

public class StringAuxiliar {
    private String s;

    public void setS(String s) {
        this.s = s;
    }
    
    boolean verificarcpf(){
        boolean veri=true;
        int i=0;
        
        if(s.length()==14){
            for(i=0; i<s.length(); i++){
                if(i>=0||i<=2){
                    if(s.charAt(i)<'0'&&s.charAt(i)>'9'){
                        veri=false;
                        break;
                    }
                }
                
                else if(i==3||i==7){
                    if(s.charAt(i)!='.'){
                        veri=false;
                        break;
                    }
                }
                
                else if(i>=4||i<=6){
                    if(s.charAt(i)<'0'&&s.charAt(i)>'9'){
                        veri=false;
                        break;
                    }
                }
                
                else if(i>=8||i<=10){
                    if(s.charAt(i)<'0'&&s.charAt(i)>'9'){
                        veri=false;
                        break;
                    }
                }
                
                else if(i==11){
                    if(s.charAt(i)!='_'){
                        veri=false;
                        break;
                    }
                }
                
                else if(i>=12||i<=13){
                    if(s.charAt(i)<'0'&&s.charAt(i)>'9'){
                        veri=false;
                        break;
                    }
                }
            }
        }
        
        else{
            veri=false;
        }
        
        System.out.print(i);
        
        return veri;
    }

    boolean quasePalindroma(){
        boolean veri=true;
        int contDiferenca=0;
        
        for(int i=0, j=s.length()-1; i<s.length(); i++, j--){
            if(s.charAt(i)!=s.charAt(j)){
                contDiferenca++;
            }
        }
        
        if(contDiferenca!=2){
            veri=false;
        }
        
        return veri;
    }
    
    public String quasePalindromaCriptografado(){
        String sCripto="";
        
        if(quasePalindroma()){
            
            
            for(int i=0, j=s.length()-1; i<s.length(); i++, j--){
                if(s.charAt(i)==s.charAt(j)){
                    sCripto+=s.charAt(i);
                }
                
                else{
                    sCripto+='_';
                }
            }
            
            
        }
        
        else{
            System.out.println("String não atende aos requisitos!");
        }
        
        return sCripto;
    }
}