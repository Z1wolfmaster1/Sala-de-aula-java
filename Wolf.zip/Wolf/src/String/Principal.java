package String;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        AuxiliarStrings frase=new AuxiliarStrings();
        int x;
        
        frase.setS(JOptionPane.showInputDialog("Digite uma frase:"));
        
        for(;;){
            x=Integer.parseInt(JOptionPane.showInputDialog("1. Contar Vogais\n2. Contar Palavras\n3. Exibir frase criptografada\n4. Verificar palíndromo\n5. Verificar email\n6. Sair"));
            
            if(x==1){
                JOptionPane.showMessageDialog(null, frase.contarVogal()+" vogais na frase.");
                
            }
            
            else if(x==2){
                JOptionPane.showMessageDialog(null, frase.contarPalavras()+" palavras na frase.");
            }
            
            else if(x==3){
                JOptionPane.showMessageDialog(null, frase.criptografar());
            }
            
            else if(x==4){
                if(frase.veriPalindromo()){
                    JOptionPane.showMessageDialog(null, "Email válido");
                }
                
                else{
                    JOptionPane.showMessageDialog(null, "Email inválido");
                }
            }
            
            else if(x==6){
                break;
            }
        }
    }
}
