package Livraria;

import java.util.Scanner;

public class Livro {

    Scanner input = new Scanner(System.in);
    String titulo, autor, genero;
    double preco;

    public Livro(String titulo, String autor, double preco) {
        this.titulo = titulo;
        this.autor = autor;
        this.preco = preco;
    }

    void visualizarDados() {
        System.out.printf("Titulo: %s\nAutor: %s\nGênero\nPreço: %.2f", titulo, autor, genero, preco);
    }

    void cadastrarLivro() {
        System.out.printf("Digite o\n");
        System.out.printf("Titulo: ");
        titulo = input.nextLine();
        System.out.printf("\nAutor: ");
        autor = input.nextLine();
        System.out.printf("\nGênero: ");
        genero = input.nextLine();
        System.out.printf("\nPreço: ");
        preco = input.nextDouble();
    }

    void reajustarPreco(double reajuste) {
        preco = preco + preco * (reajuste / 100);
    }
}
