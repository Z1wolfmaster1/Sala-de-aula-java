package Aula2;


public class Pessoa {
    private String nome, cpf, endereço;
    
    public Pessoa(String nome, String cpf, String endereço){
        this.nome=nome;
        this.cpf=cpf;
        this.endereço=endereço;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEndereço() {
        return endereço;
    }
}