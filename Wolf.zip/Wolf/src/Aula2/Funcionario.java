package Aula2;


public class Funcionario extends Pessoa {
    private String dataAdmissao;
    private double salario;
    
    public Funcionario(String nome, String cpf, String endereço, String dataAdmissao, double salario){
        super (nome, cpf, endereço);
        this.dataAdmissao=dataAdmissao;
        this.salario=salario;
    }
    
    void exibirDados(){
        
    }
    
    void reajustarSalario(double reajuste){
        setSalario(reajuste); 
    }

    public String getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(String dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    
    
}
