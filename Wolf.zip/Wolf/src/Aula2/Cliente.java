package Aula2;


public class Cliente extends Pessoa{
    String profissao;

    public Cliente(String nome, String cpf, String endereço, String profissao) {
        super(nome, cpf, endereço);
        this.profissao=profissao;
    }
    
    void exibirDados(){
        
    }

    public String getProfissao() {
        return profissao;
    }
}