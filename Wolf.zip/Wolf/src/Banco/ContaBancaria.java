package Banco;

public class ContaBancaria {
    int numero;
    private double saldo=0;

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    Cliente dono=new Cliente();

    void consultarsaldo(){
        System.out.printf("%.2f", saldo);
    }

    void depositar(double x){
        saldo+=x;
        System.out.println("Deposito efetuado.");
    }

    void sacar(double x){
        if(x<saldo){
            saldo-=x;
            System.out.println("");
        }

        else{
            System.out.println("Esse valor não pode ser sacado.");
        }
    }
}