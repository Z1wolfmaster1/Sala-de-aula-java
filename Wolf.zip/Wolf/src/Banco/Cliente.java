package Banco;

import java.util.Scanner;

public class Cliente {
    Scanner input=new Scanner(System.in);
    private String nome;
    private String rg;
    private String cpf;
    private String telefone;
    private String endereco;
    
    void cadastar(){
        System.out.println("Informe nome: ");
        nome=input.nextLine();
        
        System.out.println("Informe RG: ");
        nome=input.nextLine();
        
        System.out.println("Informe CPF: ");
        nome=input.nextLine();
        
        System.out.println("Informe Telefone: ");
        nome=input.nextLine();
        
        Endereco clientex=new Endereco();
        clientex.cadastrar();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
}