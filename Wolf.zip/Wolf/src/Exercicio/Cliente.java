package Exercicio;

public class Cliente extends Pessoa{
    int dt_prime_consulta;

    public Cliente(String nome, String cpf, String rua, String cep, int dt_prime_consulta) {
        super(nome, cpf, rua, cep);
        this.dt_prime_consulta=dt_prime_consulta;
    }
    
    public void exibir(){
        super.exibir();
        System.out.println("Data da primeira consulta: "+dt_prime_consulta);
    }
}