package Exercicio;

public class Administraçao {
    Funcionario[] fun=new Funcionario[100];
    Gerente[] gen=new Gerente[100];
    int contFun=0, contGen=0;
    
    public void admitirFuncionarios(){
        
    }
    
    public void exibirFuncionarios(){
        for(int i=0; i<contFun; i++){
            fun[i].exibir();
        }
        
        for(int i=0; i<contGen; i++){
            gen[i].exibir();
        }
    }
    
    public void atualizarFuncionario(String cpf){
        
    }
    
    public void exibirNumeroGerentes(){
        
    }
}