package Exercicio;

public class Pessoa {
    private String nome, cpf;
    private Endereço end;

    public Pessoa(String nome, String cpf, String rua, String cep) {
        end=new Endereço(rua, cep);
        this.nome = nome;
        this.cpf = cpf;
    }
    
    public Pessoa(){}

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }
    
    protected void exibir(){
        System.out.println("Nome: "+nome+"\nCPF: "+cpf);
        end.exibir();
    }

}