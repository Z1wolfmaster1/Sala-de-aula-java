package Exercicio;

public class Funcionario extends Pessoa{
    double salario;

    public Funcionario(String nome, String cpf, String rua, String cep, double salario) {
        super(nome, cpf, rua, cep);
        this.salario=salario;
    }
    
    public void exibir(){
        super.exibir();
        System.out.println("Salario: "+salario);
    }
}
