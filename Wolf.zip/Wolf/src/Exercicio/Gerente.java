package Exercicio;

public class Gerente extends Funcionario{
    double gratificaçao;

    public Gerente(String nome, String cpf, String rua, String cep, double salario, double gratificaçao) {
        super(nome, cpf, rua, cep, salario);
        this.gratificaçao=gratificaçao;
    }
    
    public void exibir(){
        super.exibir();
        System.out.println("Gratificação: "+gratificaçao);
    }
}
