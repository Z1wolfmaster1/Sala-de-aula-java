package Exercicio;

public class Endereço {
    private String rua, cep;

    public Endereço(String rua, String cep) {
        this.rua = rua;
        this.cep = cep;
    }

    public String getRua() {
        return rua;
    }

    public String getCpf() {
        return cep;
    }
    
    public void exibir(){
        System.out.println("Rua: "+rua+"\nCEP: "+cep);
    }
}