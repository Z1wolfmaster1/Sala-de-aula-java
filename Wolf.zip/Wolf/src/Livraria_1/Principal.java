package Livraria_1;

import java.util.Scanner;

public class Principal {
    public static void main(String args[]){
        Scanner input=new Scanner(System.in);
        Livraria livraria;
        double x;
        
        System.out.print("Quantos livros tem a livraria: ");
        x=input.nextDouble();
        livraria=new Livraria((int)x);
        
        for(;;){
            System.out.printf("1.\n2.\n3.\n4.\n5.\n6.\n7.\n8.\n9.\n0. Sair\n\n==> ");
            x=input.nextDouble();
            
            if(x==1){}
            else if(x==2){}
            else if(x==3){}
            else if(x==4){}
            else if(x==5){}
            else if(x==6){}
            else if(x==7){}
            else if(x==8){}
            else if(x==9){}
            else if(x==0){
                break;
            }
        }
    }
}