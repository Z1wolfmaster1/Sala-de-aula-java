package Livraria_1;

import java.util.Scanner;

public class Livraria {

    Scanner input = new Scanner(System.in);
    String nome, dono;
    Livro[] livros;
    int q = 0;

    public Livraria(int quantidade) {
        livros = new Livro[quantidade];
        nome = "Livraria Arapiraca";
        dono = "IFAL";
    }

    public Livraria(String nome, String dono) {
        livros = new Livro[10];
        this.nome = nome;
        this.dono = dono;
    }

    void adicionarLivro(Livro livro) {
        livros[q] = livro;
        q++;
    }

    int obterQuantidadeLivros() {
        return q;
    }

    void buscarLivro(String titulo) {
        
    }
    
    void exibirLivros(){}
    
    void cadastrarLivros(){}
}