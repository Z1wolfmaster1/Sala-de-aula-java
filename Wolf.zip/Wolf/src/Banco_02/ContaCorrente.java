package Banco_02;

public class ContaCorrente extends Conta{
    private double taxa;
    
    public ContaCorrente(int numeroConta, double saldo, Cliente cliente, double taxa) {
        super(numeroConta, saldo, cliente);
        this.taxa=taxa;
    }
    
}
