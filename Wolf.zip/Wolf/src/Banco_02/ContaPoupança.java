package Banco_02;

import java.util.Calendar;

public class ContaPoupança extends Conta{
    
    private int dia;
    
    public ContaPoupança(int dia, int numeroConta, double saldo, Cliente cliente) {
        super(numeroConta, saldo, cliente);
        this.dia=dia;
        //Calendar d = Calendar.getInstance();
        //dia= d.get(Calendar.DAY_OF_MONTH);
    }
    
    public void verificarAniversarioPoupança(){
        Calendar d = Calendar.getInstance();
        int dia2 = d.get(Calendar.DAY_OF_MONTH);
        if(dia==dia2){
            double valor_juros = getSaldo()*0.05;
            depositar(valor_juros);
        }
    }
}
