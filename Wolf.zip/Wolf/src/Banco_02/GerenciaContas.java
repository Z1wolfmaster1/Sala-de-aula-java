package Banco_02;

public class GerenciaContas {
    private ContaCorrente[] contasC = new ContaCorrente[30];
    private ContaPoupança[] contasP = new ContaPoupança[30];
    private int contC=0, contP=0;
    
    public void criarPoupança(ContaPoupança contaP){
        contasP[contP]=contaP;
        contP++;
    }
    
    public void criarCorrente(ContaCorrente contaC){
        contasC[contC]=contaC;
        contC++;
    }
    
    public void verPoupança0(){
        
    }
    public void verCorreente(){}
}