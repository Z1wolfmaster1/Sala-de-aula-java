package Banco_02;

import java.util.Scanner;

public class GerenciaContas {
    private ContaCorrente[] contasC = new ContaCorrente[30];
    private ContaPoupança[] contasP = new ContaPoupança[30];
    private int contC=0, contP=0;
    
    public void criarPoupança(){
        Scanner input=new Scanner(System.in);
        int numeroConta;
        double saldo;
        Cliente cliente;
        
        System.out.print("Digite o número da conta: ");
        numeroConta=input.nextInt();
        System.out.printf("\nDigite o saldo inicial da conta: ");
        saldo=input.nextDouble();
        System.out.println("Digite o nome do cliente: ");
        String nome=input.nextLine();
        System.out.println("Digite o CPF do cliente: ");
        String cpf=input.nextLine();
        cliente=new Cliente(nome, cpf);
        
        contasP[contP]=new ContaPoupança(numeroConta, saldo, cliente);
        contP++;
    }
    
    public void criarCorrente(){
        Scanner input=new Scanner(System.in);
        int numeroConta;
        double saldo, taxa;
        Cliente cliente;
        String nome, cpf;
        
        System.out.printf("Digite o número da conta: ");
        numeroConta=input.nextInt();
        
        System.out.printf("\nDigite o saldo inicial da conta: ");
        saldo=input.nextDouble();
        
        System.out.printf("\nDigite o nome do cliente: ");
        nome=input.nextLine();
        
        System.out.printf("\nDigite o CPF do cliente: ");
        cpf=input.nextLine();
        cliente=new Cliente(nome, cpf);
        
        System.out.printf("\nDigite a taxa sobre o saldo: ");
        taxa=input.nextDouble();
        
        contasC[contC]=new ContaCorrente(numeroConta, saldo, cliente, taxa);
        contP++;
    }
    
    public void verPoupança(){
        for(int i=0; i<contP; i++){
            contasP[i].exibirDados();
        }
        
    }
    public void verCorrente(){
        for(int i=0; i<contC; i++){
            contasC[i].exibirDados();
        }
    }
    
    public void veriNome(String nome){
        boolean v=false;
        int j=1;
        System.out.println("Resultados para"+nome+":\n");
        for(int i=0; i<contP; i++){
            if(contasP[i].getNomeCliente().equalsIgnoreCase(nome)){
            System.out.println("Cliente Nº"+j+": "+contasP[i].getNumeroConta());
            v=true;
            }
        }
        
        for(int i=0; i<contC; i++){
            if(contasC[i].getNomeCliente().equalsIgnoreCase(nome)){
            System.out.println("Cliente Nº"+j+": "+contasC[i].getNumeroConta());
            v=true;
            }
        }
        
        
    }
}