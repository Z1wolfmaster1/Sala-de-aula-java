package Banco_02;


public class GerenciaContas {
    ContaCorrente[] contasC = new ContaCorrente[30];
    ContaPoupança[] contasP = new ContaPoupança[30];
    
    void criarPoupança(){
        
    }
    
    void criarCorrente(){
        
    }
}
