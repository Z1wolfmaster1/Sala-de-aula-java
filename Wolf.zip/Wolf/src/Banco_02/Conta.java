package Banco_02;

public class Conta{
    private Cliente cliente;
    private int numeroConta;
    private double saldo;
    
    public Conta(int numeroConta, double saldo, Cliente cliente){
        this.cliente=cliente;
        this.numeroConta=numeroConta;
        this.saldo=saldo;
    }
    
    public boolean depositar(double valor){
        if(valor>0){
            saldo+=valor;
            return true;
        }
        
        else{
            return false;
        }
    }
    
    public boolean sacar(double valor){
        if(valor<=saldo){
            saldo-=valor;
            return true;
        }
        
        else{
            return false;
        }
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public double getSaldo() {
        return saldo;
    }
    
    
}