package Banco_02;

import java.util.Scanner;

public class Principal {
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        
    }
}
