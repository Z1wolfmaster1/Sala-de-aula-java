package Banco_02;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String args[]){
        GerenciaContas contas=new GerenciaContas();
        Scanner input = new Scanner(System.in);
        int x;
        
        for(;;){
            x=Integer.parseInt(JOptionPane.showInputDialog("1. Cadastrar conta\n2. Visualizar contas\n3. Verificar cliente\n4. Depósito\n5. Saque\n6. Sair"));
            
            if(x==1){
                for(;;){
                    x=Integer.parseInt(JOptionPane.showInputDialog("1. Poupança\n2. Corrente\n3. Cancelar"));
                
                    if(x==1){
                        contas.criarPoupança();
                    }
                    if(x==2){
                        contas.criarCorrente();
                    }
                    if(x==3){
                        break;
                    }

                    else{
                        JOptionPane.showMessageDialog(null, "Opção inexistente!");
                    }
                }
            }
            else if(x==2){}
            else if(x==3){}
            else if(x==4){}
            else if(x==5){}
            else if(x==6){
                break;
            }
        }
    }
}
