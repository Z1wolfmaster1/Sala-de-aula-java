package Exercicio_3;

public class Supervisor extends Funcionario{
    double salario;
    
    
}
