package Exercicio_3;

abstract class Funcionario {
    private String cpf, nome;
    
    public double calcularSalarioPagar(double x, double y, Funcionario f){
        double valor = 0;
        
        if(f instanceof Supervisor){
            valor=x+(y/2);
        }
        
        else if(f instanceof Vendedor){
            valor=x*0.3;
        }
        
        else if(f instanceof Horista){
            valor=x*y;
        }
        
        return valor;
    }
}
