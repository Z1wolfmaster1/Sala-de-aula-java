package Exercicio_3;

public class Horista extends Funcionario{
    
}
