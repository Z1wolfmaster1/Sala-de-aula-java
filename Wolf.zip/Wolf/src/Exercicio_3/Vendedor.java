package Exercicio_3;

public class Vendedor extends Funcionario{
    
}
